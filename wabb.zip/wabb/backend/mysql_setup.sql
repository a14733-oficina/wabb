-- Executar como root do MySQL:  mysql -u root -p < mysql_setup.sql
CREATE DATABASE IF NOT EXISTS wabb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'wabb_user'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON wabb.* TO 'wabb_user'@'localhost';
FLUSH PRIVILEGES;
-- As tabelas são criadas automaticamente pelo SQLAlchemy (python -m app.seed).
